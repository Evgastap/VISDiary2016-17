diary
=====

The Diary

## Dependencies

* Node.js
* [PhantomJS](http://phantomjs.org/)
* [PDFTk ("server")](http://www.pdflabs.com/tools/pdftk-server/)

To just start the static file server:

```Bash
$ ./node_modules/.bin/http-server output -p 7472
```
